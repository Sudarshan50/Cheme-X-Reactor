export const shimpson = (a, b, val1, val2, val3) => {
  return ((b - a) / 6) * (val1 + 4 * val2 + val3);
};

export const cds = ()=>{
       
}
