import "./styles.css";
import "./app.css";
import Layout from "./components/Layout/layout.js";

export default function App() {
  return (
    <Layout/>
  );
}
